package kodlama.io.E.Trade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ETradeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ETradeApplication.class, args);
	}

}
