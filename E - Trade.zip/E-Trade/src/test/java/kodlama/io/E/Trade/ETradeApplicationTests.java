package kodlama.io.E.Trade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ETradeApplicationTests {

	@Test
	void contextLoads() {
	}

}
